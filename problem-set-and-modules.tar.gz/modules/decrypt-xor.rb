require "bigdecimal"

module Decrypt_XOR
  class DecryptXOR < Hash
    attr_accessor :digest                                                         
    attr_reader :key_vals, :clear_string, :found_key, :found_index, :max_score
    def initialize(digest, keyVals)
      @digest = digest
      @key_vals = keyVals
    end
  
    def new_digest(newDigest)
      @digest = newDigest
      #Delete all entries to remove scores
      self.delete_if{|key, value| key === key}
    end
   
    def init_frequency
      init_freq = {}
      init_freq[' '] = 19 
      init_freq['e'] = 12 
      init_freq['t'] =  9
      init_freq['a'] =  8 
      init_freq['o'] =  8 
      init_freq['i'] =  7 
      init_freq['n'] =  7 
      init_freq['s'] =  6 
      init_freq['h'] =  6 
      init_freq['r'] =  6 
      init_freq['d'] =  4 
      init_freq['l'] =  4 
      init_freq['c'] =  3 
      init_freq['u'] =  3 
      init_freq['m'] =  2 
      init_freq['w'] =  2 
      init_freq['f'] =  2 
      init_freq['g'] =  2 
      init_freq['y'] =  2 
      init_freq['p'] =  2 
      init_freq['b'] =  1 
      init_freq['v'] =  1 
      init_freq['k'] =  1 
      init_freq['j'] =  1 
      init_freq['x'] =  1 
      init_freq['q'] =  1 
      init_freq['z'] =  1 
      return init_freq
    end

    def init_count(text)
      #Switch to lower case to regularize comparisons
      text_low = text.downcase
  
      #Store letter count for each letter in string  
      count = {}
      for letter in 'a'..'z' do
        count[letter] = text_low.count(letter)
      end
  
      count[' '] = text_low.count(' ')
      return count
    end

    def frequency_score(count, length)
      char_freq = {}
      count.each {|char, hits|
        char_freq[char] = (hits / BigDecimal(length)) * 100
      }
  
      #Add 1 to score if character frequencies match expected values
      score = 0
      stdev = BigDecimal("1.75")
      exp_freq = init_frequency()
      char_freq.each_key {|char|
        delta_hi = exp_freq[char] + stdev
        delta_lo = exp_freq[char] - stdev
        
        if (char_freq[char] <= delta_hi) && (char_freq[char] >= delta_lo)
             score += 1 
        end
      }

      return score
    end
  
    def decrypt
      #XOR each key value with digest
      #Give each a default score of zero
      @key_vals.each {|k| self[@digest.sc_xor(k)] = 0}
  
      self.each {|line, score| 
        #skip strings containing non-ASCII chars
        next unless line.ascii_only? 
    
        #Score line based on letter frequency
        char_count = init_count(line)
        length = line.size
        score = frequency_score(char_count, length)
        
        #check for conditions less likely in an English string of text
        if ( line.match(/[a-z][A-Z]{2,}/) ) then score -= 5 end
        if line.match(/[a-zA-Z][.?!][a-zA-Z]/) then score -= 5 end 
        if line.match(/[a-zA-Z][0-9][a-zA-Z]/) then score -= 5 end 
        if line.match(/[^a-zA-Z0-9 .,!'?]/) then score -= 5 end 
        if line.match(/[^a-zA-Z0-9_ ]/) == nil then score += 5 end #zero non-word chars 
        
        self[line] = score
      }
    end
  
    def get_results
      return nil unless self.values
      #Convert Hash to Array
      #Makes finding correct key index easier
      candidates_array = self.to_a
      @max_score = self.values.max
  
      candidates_array.each_with_index {|string, index|
        if string[1] == @max_score
          @found_index = index 
          @clear_string = string[0]
        end 
      }
  
      (@found_key = @key_vals[@found_index]) unless @found_index.nil?
    end
  end
end
